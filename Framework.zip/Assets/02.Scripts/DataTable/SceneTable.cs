using System.Collections;
using System.Collections.Generic;

namespace DataTable
{
    public static class SceneTable
    {
        //���� �̸� = �� �̸� �������� ��ġ
        public const string STR_SCENE_LOGIN = "LoginPage";
        public const string STR_SCENE_LODING = "LodingPage";
        public const string STR_SCENE_MAINPAGE = "MainPage";
        public const string STR_SCENE_GAMEPAGE = "GamePage";
    }
}
