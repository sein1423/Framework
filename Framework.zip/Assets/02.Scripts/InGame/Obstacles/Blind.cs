using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Blind : MonoBehaviour
{
    private float offset;

    private void Awake()
    {
        gameObject.SetActive(false);
        offset = Player.instance.transform.position.y - transform.position.y;
    }
    private void Update()
    {
        if (GameManager.instance.b_blindActive)
        {
            Debug.Log("Blind Active");
            gameObject.SetActive(true);
            Vector3 playerPos = Player.instance.transform.position;
            gameObject.transform.position = new Vector3(playerPos.x, playerPos.y - offset, playerPos.z);
        }
    }
}
