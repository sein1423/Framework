using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpeedUp : MonoBehaviour
{
    public float upSpeed = 1.5f;
    
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("Player"))
        {
            GameManager.instance.combo = 0;
            Player.instance.GravityUp(upSpeed);
            gameObject.SetActive(false);
        }
    }
}
