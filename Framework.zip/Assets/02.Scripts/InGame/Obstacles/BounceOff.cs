using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BounceOff : MonoBehaviour
{
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.CompareTag("Player"))
        {
            GameManager.instance.expTotal -= GameManager.instance.expTotal / 5;
            GameManager.instance.combo = 0;
        }
    }
}
