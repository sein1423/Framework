using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlindItem : MonoBehaviour
{

    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.CompareTag("Player"))
        {
            GameManager.instance.b_blindActive = true;
            GameManager.instance.combo = 0;
            gameObject.SetActive(false);
        }
    }
}
