using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIManager : Singleton<UIManager>
{
    public Text scoreText;
    public Text countDownText;
    public Text feverText;
    private void Update()
    {
        scoreText.text = "Score : " + GameManager.instance.expTotal;
        ShowCountDown();
        ShowFeverText();
    }

    /// <summary>
    /// ī��Ʈ �ٿ� ǥ��
    /// </summary>
    private void ShowCountDown()
    {
        countDownText.text = GameManager.instance.i_startCount.ToString();

        if (GameManager.instance.i_startCount == 0)
        {
            countDownText.color = Color.yellow;
            countDownText.text = "Game Start!";
        }
    }

    private void ShowFeverText()
    {
        if(GameManager.instance.b_startFever)
        {
            feverText.gameObject.SetActive(true);
        }

        else
            feverText.gameObject.SetActive(false);
    }
}
