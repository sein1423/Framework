using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class CameraMove : MonoBehaviour
{
    private Vector3 cameraPos;
    private float xPos, yPos;
    public Transform targetTransform;

    private void Update() // Ÿ�� Ʈ�������� ���� ������
    {
        xPos = targetTransform.position.x;
        yPos = targetTransform.position.y -2;
        if (yPos < 1)
            yPos = 1;
        transform.position = new Vector3(xPos, yPos, -10);
    }
}
